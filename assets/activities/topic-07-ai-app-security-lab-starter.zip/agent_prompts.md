# Agent And Programming Prompt Log

Use this file only if you relied on AI assistance in a meaningful way while completing the lab.

## Tools Used

-

## Prompts, Transcript Excerpts, Or Summaries

1.
2.

## What You Kept, Changed, Or Rejected

-

"""Mixed-trust retrieval helpers for the AI Application Security Lab."""

from __future__ import annotations

import re
from pathlib import Path


def tokenize(text: str) -> set[str]:
    return set(re.findall(r"[a-zA-Z0-9_:-]+", text.lower()))


def chunk_text(text: str, chunk_size: int = 120) -> list[str]:
    words = text.split()
    if not words:
        return []
    return [" ".join(words[i : i + chunk_size]) for i in range(0, len(words), chunk_size)]


def infer_visibility(path: Path) -> str:
    return "internal" if "internal" in path.parts else "public"


def build_retrieval_corpus(data_dir: str | Path) -> list[dict]:
    corpus: list[dict] = []
    for path in sorted(Path(data_dir).rglob("*.txt")):
        visibility = infer_visibility(path)
        text = path.read_text(encoding="utf-8").strip()
        for index, chunk in enumerate(chunk_text(text), start=1):
            corpus.append(
                {
                    "source": f"{path.name}#chunk{index}",
                    "path": str(path),
                    "filename": path.name,
                    "visibility": visibility,
                    "text": chunk,
                    "tokens": tokenize(chunk),
                    "is_poisoned": "supplemental_notes_from_ta" in path.name,
                }
            )
    return corpus


def score_entry(query_tokens: set[str], entry: dict, allow_internal: bool) -> tuple[int, int, int]:
    overlap = len(query_tokens & entry["tokens"])
    visibility_penalty = 0

    # Patch point for the optional hardening path:
    # this only penalizes internal entries instead of excluding them from
    # student-facing retrieval. That makes the system feel realistic but brittle.
    if entry["visibility"] == "internal" and not allow_internal:
        visibility_penalty = -1

    poison_bonus = 1 if entry["is_poisoned"] and query_tokens & {"audit", "verify", "blocked", "internal", "quote"} else 0
    return (overlap + visibility_penalty + poison_bonus, overlap, len(entry["text"]))


def retrieve_context(query: str, corpus: list[dict], top_k: int = 4, allow_internal: bool = False) -> list[dict]:
    query_tokens = tokenize(query)
    ranked = sorted(
        corpus,
        key=lambda entry: score_entry(query_tokens, entry, allow_internal),
        reverse=True,
    )
    selected = [entry for entry in ranked if score_entry(query_tokens, entry, allow_internal)[0] > 0]
    if not selected:
        selected = ranked[:top_k]
    return selected[:top_k]


def summarize_sources(corpus: list[dict]) -> str:
    public = sorted({entry["filename"] for entry in corpus if entry["visibility"] == "public"})
    internal = sorted({entry["filename"] for entry in corpus if entry["visibility"] == "internal"})
    lines = [
        f"Loaded {len(public)} public documents and {len(internal)} internal documents.",
        "Public:",
    ]
    lines.extend(f"- {name}" for name in public)
    lines.append("Internal:")
    lines.extend(f"- {name}" for name in internal)
    return "\n".join(lines)


def format_context(entries: list[dict]) -> str:
    lines: list[str] = []
    for entry in entries:
        lines.append(f"[Source: {entry['source']} | visibility: {entry['visibility']}]")
        lines.append(entry["text"])
        lines.append("")
    return "\n".join(lines).strip()

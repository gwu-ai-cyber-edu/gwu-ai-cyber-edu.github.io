# Ollama Setup

This lab is designed to run against a **local LLM** so you do not need an institutional API key.
The default backend is [Ollama](https://ollama.com), which exposes an OpenAI-compatible API at
`http://localhost:11434/v1`.

If you want to use a hosted OpenAI-compatible service instead, skip to "Hosted Fallback" below.

## Install Ollama

- macOS: download the installer from <https://ollama.com/download> and run it. Ollama installs as a background app.
- Linux: `curl -fsSL https://ollama.com/install.sh | sh`
- Windows: download the installer from <https://ollama.com/download/windows>.

After install, confirm the server is running:

```bash
ollama --version
curl http://localhost:11434/api/tags
```

The second command should return a JSON list of installed models (initially empty).

## Pull A Small Model

For this lab a small instruction-tuned model is plenty. Any of the following will work; pick one
that fits your machine:

```bash
# About 2 GB. Recommended starting point.
ollama pull llama3.2:3b

# About 2 GB. Slightly different refusal behavior; nice to compare.
ollama pull qwen2.5:3b-instruct

# About 1.6 GB. Smallest of the three.
ollama pull gemma2:2b
```

Confirm the model is available:

```bash
ollama list
```

You can interact with the model directly from the command line as a sanity check:

```bash
ollama run llama3.2:3b "Say hello in one short sentence."
```

## Point The Lab At Ollama

Copy `.env.example` to `.env` and confirm the defaults match the model you pulled:

```bash
cp .env.example .env
```

The defaults are:

```
LLM_BASE_URL=http://localhost:11434/v1
LLM_API_KEY=ollama
LLM_MODEL=llama3.2:3b
```

`LLM_API_KEY=ollama` is a placeholder; the local server ignores the value but the OpenAI client
library still requires the field.

## Run A Smoke Test

```bash
python3 -m venv .venv
source .venv/bin/activate         # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python3 app.py --list-sources
python3 app.py --question "What is retrieval-augmented generation?"
```

If the second command prints a paragraph from the model, you are ready to start the attack tasks.

## Hosted Fallback

If Ollama will not install on your machine, you can use any OpenAI-compatible service. Edit `.env`
and set the three values to point at your endpoint. For OpenAI itself:

```
LLM_BASE_URL=https://api.openai.com/v1
LLM_API_KEY=sk-...
LLM_MODEL=gpt-4o-mini
```

Other compatible options include OpenRouter, Groq, vLLM, llama.cpp's server, LM Studio's local
server, and many institutional gateways. As long as the endpoint speaks the OpenAI Chat
Completions API, the lab will work without code changes.

## Troubleshooting

- **`Connection refused` on `localhost:11434`** — Ollama is not running. On macOS, open the Ollama
  app from Applications. On Linux, run `ollama serve &` or check `systemctl status ollama`.
- **The model takes 30+ seconds per response** — that is normal for a 2 - 3 B parameter model on a
  laptop CPU. Ask shorter questions or pick a smaller model.
- **The model returns invalid JSON in `--generate-quiz` or `--grade-question`** — small local models
  sometimes ignore the JSON response-format hint. Re-run, or temporarily switch to a larger
  hosted model for those two paths.
- **`response_format` rejected by your hosted endpoint** — comment out the `response_format` line
  in `llm_client.py:complete_json` and rely on the system prompt to request JSON. The lab will
  still demonstrate the leakage behavior.

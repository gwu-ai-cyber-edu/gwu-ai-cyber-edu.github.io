# Analysis

Use this file to explain the root causes of the leakage behavior you observed and the defenses you would prioritize.

## Leakage Targets

- Which kinds of internal or protected information were present in the system?
- Which ones were easiest to expose?
- Which ones resisted extraction better?

## Root Cause Analysis

Discuss how the observed behavior relates to:

- prompt assembly
- retrieval design
- output formatting or explanation behavior
- the difference between prompt-level guardrails and real enforcement

## Compare The Three Attack Paths

- Which path required the least attacker effort?
- Which path produced the highest-value leakage?
- Which path depended most on retrieval behavior?
- Which path depended most on weak instruction-following or output handling?

## Defense Ideas

Describe at least two realistic defenses for this application.

For each defense:

- what it changes
- what attack path it targets
- what tradeoff it introduces

## Optional Patch Reflection

If you implemented a small patch, describe:

- what you changed
- why you chose that patch point
- what changed when you re-tested
- what residual risk remained

If you did not patch the code, explain which patch you would implement first and why.

"""Configuration for the AI Application Security Lab starter."""

from __future__ import annotations

import os
from pathlib import Path


ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "data"
PUBLIC_DATA_DIR = DATA_DIR / "public"
INTERNAL_DATA_DIR = DATA_DIR / "internal"

DEFAULT_STUDY_PROMPT_PATH = ROOT / "templates" / "study_assistant_prompt.txt"
DEFAULT_QUIZ_PROMPT_PATH = ROOT / "templates" / "quiz_system_prompt.txt"
DEFAULT_GRADING_PROMPT_PATH = ROOT / "templates" / "grading_prompt.txt"


def env(name: str, default: str = "") -> str:
    return os.getenv(name, default).strip()


# Default backend is a local Ollama server, which exposes an OpenAI-compatible
# API at http://localhost:11434/v1. Ollama ignores the API key but the SDK
# still requires the field, so we set a placeholder. Override LLM_BASE_URL,
# LLM_API_KEY, and LLM_MODEL to point at any other OpenAI-compatible service.
LLM_BASE_URL = env("LLM_BASE_URL", "http://localhost:11434/v1")
LLM_API_KEY = env("LLM_API_KEY", "ollama")
LLM_MODEL = env("LLM_MODEL", "llama3.2:3b")

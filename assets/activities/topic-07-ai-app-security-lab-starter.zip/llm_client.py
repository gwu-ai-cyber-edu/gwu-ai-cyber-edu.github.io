"""LLM helpers for the AI Application Security Lab.

By default this calls a local Ollama server at http://localhost:11434/v1, which
exposes an OpenAI-compatible API. Override LLM_BASE_URL, LLM_API_KEY, and
LLM_MODEL via environment variables (or the .env file) to point at any other
OpenAI-compatible endpoint, including hosted OpenAI itself.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import config


def load_prompt(path: str | Path) -> str:
    return Path(path).read_text(encoding="utf-8").strip()


def make_client():
    from openai import OpenAI

    if not config.LLM_API_KEY:
        raise RuntimeError("LLM_API_KEY is not set (set to 'ollama' for a local server)")
    if not config.LLM_MODEL:
        raise RuntimeError("LLM_MODEL is not set")
    if not config.LLM_BASE_URL:
        raise RuntimeError("LLM_BASE_URL is not set")

    return OpenAI(api_key=config.LLM_API_KEY, base_url=config.LLM_BASE_URL)


def complete_text(system_prompt_path: str | Path, user_content: str) -> str:
    prompt = load_prompt(system_prompt_path)
    client = make_client()
    response = client.chat.completions.create(
        model=config.LLM_MODEL,
        messages=[
            {"role": "system", "content": prompt},
            {"role": "user", "content": user_content},
        ],
    )
    content = response.choices[0].message.content or ""
    if not content.strip():
        raise ValueError("model returned an empty response")
    return content.strip()


def complete_json(system_prompt_path: str | Path, payload: dict[str, Any]) -> dict[str, Any]:
    prompt = load_prompt(system_prompt_path)
    client = make_client()
    # Many local OpenAI-compatible servers honor response_format hints; if a
    # backend does not, the wrapping json.loads call surfaces the failure.
    response = client.chat.completions.create(
        model=config.LLM_MODEL,
        response_format={"type": "json_object"},
        messages=[
            {"role": "system", "content": prompt},
            {"role": "user", "content": json.dumps(payload)},
        ],
    )
    content = response.choices[0].message.content or ""
    if not content.strip():
        raise ValueError("model returned an empty JSON response")
    return json.loads(content)


def answer_question(question: str, retrieved_context: str) -> str:
    user_content = json.dumps({"question": question, "retrieved_context": retrieved_context})
    return complete_text(config.DEFAULT_STUDY_PROMPT_PATH, user_content)


def generate_quiz(retrieved_context: str) -> dict[str, Any]:
    payload = {"retrieved_context": retrieved_context}
    return complete_json(config.DEFAULT_QUIZ_PROMPT_PATH, payload)


def grade_answer(question: str, answer: str, retrieved_context: str) -> dict[str, Any]:
    payload = {
        "question": question,
        "answer": answer,
        "retrieved_context": retrieved_context,
    }
    return complete_json(config.DEFAULT_GRADING_PROMPT_PATH, payload)

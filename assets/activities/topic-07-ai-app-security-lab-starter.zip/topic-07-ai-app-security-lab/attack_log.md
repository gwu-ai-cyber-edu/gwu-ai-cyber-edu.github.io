# Attack Log

Use this file to document your attacks against the AI Application Security Lab.

Include enough detail that a reviewer can understand:

- what you tried
- which application path you used (`--question`, `--generate-quiz`, or `--grade-question`)
- what happened
- why you think it succeeded, partly succeeded, or failed

You may include short terminal excerpts or screenshots separately if needed, but summarize the important behavior here in your own words.

## System Summary

- What commands or app paths did you test?
- What kinds of data sources or document classes were loaded?
- Which parts of the application seemed most likely to leak information?

## Direct Leakage Attempt

- Goal:
- Prompt or command used:
- Retrieved or observed behavior:
- What sensitive or internal content, if any, was exposed:
- Why you think this path did or did not work:

## Guardrail Bypass Attempt

- Goal:
- Prompt or command used:
- Guardrail you were trying to bypass:
- Retrieved or observed behavior:
- What sensitive or internal content, if any, was exposed:
- Why you think this path did or did not work:

## Retrieval Abuse Attempt

- Goal:
- Prompt or command used:
- What retrieved or adversarial content you think mattered:
- Retrieved or observed behavior:
- What sensitive or internal content, if any, was exposed:
- Why you think this path did or did not work:

## Model Comparison (Optional)

Only if you ran the optional cross-model cell. Rerun your single strongest attack against a second model (e.g., `llama3.1:8b` vs. `llama3.2:3b`).

- Attack reused (which prompt/path):
- Model A and what it leaked (chunks, `LAB7-CANARY-*` strings, refusal):
- Model B and what it leaked:
- Which model leaked more, and roughly how much faster the smaller model was:
- What this implies about choosing a model as a security decision:

## Best Attack

- Which attempt was most effective:
- Which leakage target was exposed:
- Why this attack path was stronger than the others:

# Colab Setup

This lab runs in Google Colab. The notebook installs and starts a local
[Ollama](https://ollama.com) server inside the Colab runtime, pulls a Meta
Llama 3.1 8B Instruct model, and runs the four CLI paths of the shipped
study and quiz assistant against it. No API keys, no local installs.

## Upload the starter to Google Drive

The notebook reads the starter from your Google Drive (no git, no API keys):

1. **Unzip** `topic-07-ai-app-security-lab-starter.zip` on your computer to get
   the `topic-07-ai-app-security-lab` folder.
2. **Upload the whole `topic-07-ai-app-security-lab` folder to your Google
   Drive,** ideally at the top of *My Drive* (so it lives at
   `My Drive/topic-07-ai-app-security-lab`). Upload it as-is so `data/`,
   `templates/`, and the app files come along.

## Open the notebook

1. From a Google account, open Colab: <https://colab.research.google.com/>.
2. Open `lab.ipynb` from the folder you just uploaded (File → Open notebook →
   Google Drive, then browse to `topic-07-ai-app-security-lab/lab.ipynb`).
3. From the menu, choose **Runtime → Change runtime type → T4 GPU**.

## Run the cells top to bottom

The notebook is organized into ten numbered sections:

1. Confirm GPU runtime.
2. Mount Drive and copy the starter into `/content/lab`. If you uploaded the
   folder somewhere other than the top of My Drive, edit `STARTER_DIR` in this
   cell to match.
3. Install Python dependencies.
4. Install Ollama and start the server in the background.
5. Pull `llama3.1:8b` (≈4.7 GB, one-time download).
6. Smoke-test the four CLI paths.
7. Hour 1 attack workspace (direct leakage, guardrail bypass, retrieval abuse).
8. Optional patch path in `rag_store.py`.
9. Write your analysis.
10. Bundle and download deliverables.

## What to edit while you work

- `attack_log.md` — required, one entry per attack family.
- `analysis.md` — required, root-cause comparison and at least two defenses.
- `agent_prompts.md` — required only if AI assistance materially shaped your work.
- `rag_store.py` — only if you take the optional patch path.

All four live in `/content/lab/` in the Colab file browser (folder icon on
the left). You can edit them directly in Colab.

## Saving your work

Colab runtimes are ephemeral. Two options:

- **Download bundle.** Section 10 of the notebook zips your deliverables and
  triggers a browser download. Easiest path.
- **Google Drive.** Your Drive is already mounted at `/content/drive` from
  Section 2, so you can copy your edited files into a folder you control (for
  example back into `topic-07-ai-app-security-lab`).

If your runtime disconnects, you can re-run sections 1–5 to get back to a
working environment; the pulled model is re-downloaded for the new runtime.

## Troubleshooting

- **`nvidia-smi: command not found`** — the runtime is CPU-only. Switch to
  T4 via Runtime → Change runtime type.
- **`ollama: command not found` in section 5** — section 4 has not finished.
  Re-run the install cell.
- **`Connection refused` on `localhost:11434`** — `ollama serve` did not
  start. Check `/tmp/ollama.log` and re-run the start cell.
- **`--generate-quiz` or `--grade-question` returns invalid JSON** — small
  models occasionally ignore the JSON response-format hint. Re-run the cell;
  if it keeps failing, you can comment out the `response_format=` line in
  `llm_client.py:complete_json` and rely on the system prompt.
- **`ollama pull` is slow or times out** — Colab egress is variable. Retry
  the pull cell; partial downloads resume.
- **Runtime hits the idle limit** — start the runtime at the very beginning
  of the activity so the model pull overlaps with the framing slides.

"""AI Application Security Lab: a deliberately weak retrieval-based study and quiz assistant."""

from __future__ import annotations

import argparse
import json
import sys

try:
    from dotenv import load_dotenv
except ImportError:  # pragma: no cover
    def load_dotenv() -> None:
        return None

import config
from llm_client import answer_question, generate_quiz, grade_answer
from rag_store import build_retrieval_corpus, format_context, retrieve_context, summarize_sources


def make_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser()
    parser.add_argument("--list-sources", action="store_true", help="List the loaded document sources")
    parser.add_argument("--question", help="Ask the study assistant a question")
    parser.add_argument("--generate-quiz", action="store_true", help="Generate a short quiz from the corpus")
    parser.add_argument("--grade-question", help="Question to grade against retrieved context")
    parser.add_argument("--student-answer", default="", help="Student answer for grading mode")
    return parser


def main() -> int:
    load_dotenv()
    parser = make_parser()
    args = parser.parse_args()

    corpus = build_retrieval_corpus(config.DATA_DIR)
    if not corpus:
        print("[error] corpus is empty")
        return 1

    if args.list_sources:
        print(summarize_sources(corpus))
        return 0

    if args.question:
        context = format_context(retrieve_context(args.question, corpus, top_k=4, allow_internal=False))
        print(answer_question(args.question, context))
        return 0

    if args.generate_quiz:
        query = "Generate a quiz that reflects the course study materials and note key risks."
        context = format_context(retrieve_context(query, corpus, top_k=5, allow_internal=False))
        print(json.dumps(generate_quiz(context), indent=2))
        return 0

    if args.grade_question:
        if not args.student_answer:
            print("[error] --student-answer is required with --grade-question")
            return 2
        context = format_context(retrieve_context(args.grade_question, corpus, top_k=3, allow_internal=False))
        print(json.dumps(grade_answer(args.grade_question, args.student_answer, context), indent=2))
        return 0

    parser.print_help()
    return 2


if __name__ == "__main__":
    sys.exit(main())

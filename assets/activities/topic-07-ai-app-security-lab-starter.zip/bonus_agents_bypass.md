# Optional Bonus: `AGENTS.md` Bypass

Complete this file only if you pursue the optional `AGENTS.md` bonus challenge.

## Bypass Goal

- What part of `AGENTS.md` were you trying to work around?

## Reproducible Prompt Or Prompt Sequence

1.
2.
3.

## Observed Behavior

- What did the assistant do that suggests the guidance was bypassed?
- What conditions mattered for reproducing it?

## Optional Patch

If you are pursuing the extra patch bonus:

- What patch to `AGENTS.md` or the workflow do you propose?
- Why should it make your bypass harder?
- How should staff re-test it?

# Reflection

Use this file to answer the lab's written reflection questions after you complete `ids_colab_explorer.ipynb`, `evaluation_notes.md`, and `best_model.py`. You may refer to specific metrics or tables from your notebook and evaluation notes instead of copying every table here.

For each prompt, write your response on the indented line that begins `Answer here:`. Replace that placeholder text with your own answer.

## Questions To Answer

### Security Error Tradeoffs

- Which errors are more costly in this lab: false positives or false negatives?
  - Answer here: replace this line with your answer.
- Why does that tradeoff matter for an intrusion detection workflow?
  - Answer here: replace this line with your answer.

### Human Review

- What would a human analyst need to see before acting on a model alert?
  - Answer here: replace this line with your answer.
- What additional evidence would you want before deploying this model in a security workflow?
  - Answer here: replace this line with your answer.
- What should this model not decide on its own?
  - Answer here: replace this line with your answer.

### Dataset Assumptions And Limits

- What assumptions does the synthetic dataset make about attack behavior?
  - Answer here: replace this line with your answer.
- How would your conclusions change if the dataset were much larger, noisier, or more imbalanced?
  - Answer here: replace this line with your answer.
- What would make a withheld challenge set fair for comparing different models?
  - Answer here: replace this line with your answer.

### Classifier Comparison

- Did the train/test result and cross-validation result tell the same story?
  - Answer here: replace this line with your answer.
- Which classification technique worked best, and how does that connect to supervised learning concepts from Week 1?
  - Answer here: replace this line with your answer.
- Which classifier was easiest to explain to a security analyst?
  - Answer here: replace this line with your answer.
- Which classifier would you trust least in an IDS workflow? Why?
  - Answer here: replace this line with your answer.

### Pipeline Transfer

- What feature engineering did you transfer into `best_model.py`?
  - Answer here: replace this line with your answer.
- What model did you transfer into `train_best_model`?
  - Answer here: replace this line with your answer.
- What metadata or threshold did you include for private scoring?
  - Answer here: replace this line with your answer.
- How did you check that `predict_best_model` returns valid 0/1 predictions?
  - Answer here: replace this line with your answer.

## Final Improvement

- What would you improve before using this model in a more realistic environment?
  - Answer here: replace this line with your answer.

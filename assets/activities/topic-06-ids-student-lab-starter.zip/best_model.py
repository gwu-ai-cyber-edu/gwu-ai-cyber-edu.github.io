import pandas as pd


LEAKAGE_COLUMNS = ["label", "attack_category"]
DEFAULT_DROP_COLUMNS = ["timestamp", "source_ip", "destination_ip"]


def add_features(df):
    """Return a copy of df with any derived features used by your final model."""
    result = df.copy()

    # TODO: Add derived features that you found useful in the notebook.
    # Examples:
    # result["bytes_total"] = result["bytes_sent"] + result["bytes_received"]
    # result["bytes_sent_ratio"] = result["bytes_sent"] / (result["bytes_received"] + 1)
    # result["packets_total"] = result["total_fwd_packets"] + result["total_bwd_packets"]
    # result["failed_login_rate"] = result["failed_logins"] / (result["login_attempts"] + 1)
    # result["is_scripted_user_agent"] = result["user_agent"].str.contains(
    #     "curl|python-requests|sqlmap|nmap|Headless", case=False, regex=True
    # ).astype(int)
    # result["is_unusual_port"] = (~result["destination_port"].isin([80, 443, 53, 22])).astype(int)

    return result


def make_features(df, feature_columns=None):
    """Create model features without using label or attack_category."""
    enriched = add_features(df)
    drop_columns = LEAKAGE_COLUMNS + DEFAULT_DROP_COLUMNS
    base = enriched.drop(columns=drop_columns, errors="ignore")
    features = pd.get_dummies(base, columns=base.select_dtypes(include="object").columns)

    if feature_columns is not None:
        features = features.reindex(columns=feature_columns, fill_value=0)

    return features


def make_target(df):
    return (df["label"] == "suspicious").astype(int)


def train_best_model(train_df):
    """Train and return your selected final model plus metadata.

    Return:
        model: trained model or pipeline
        metadata: dict containing at least {"feature_columns": [...]}.
    """
    # TODO: Import and configure your selected model here.
    # You may use any scikit-learn compatible classifier or pipeline.
    # Example:
    # from sklearn.ensemble import RandomForestClassifier
    # model = RandomForestClassifier(n_estimators=100, random_state=42, class_weight="balanced")

    X = make_features(train_df)
    y = make_target(train_df)

    model = None  # TODO: replace with your selected trained classifier.
    if model is None:
        raise NotImplementedError("Create and train your selected best model before submitting.")

    model.fit(X, y)
    metadata = {
        "feature_columns": list(X.columns),
        "threshold": 0.5,
        "model_name": "TODO: describe your selected model",
    }
    return model, metadata


def predict_best_model(model, metadata, test_df):
    """Return 0/1 predictions for the instructor's withheld test set."""
    feature_columns = metadata["feature_columns"]
    threshold = metadata.get("threshold", 0.5)
    X_test = make_features(test_df, feature_columns=feature_columns)

    if hasattr(model, "predict_proba"):
        scores = model.predict_proba(X_test)[:, 1]
        return (scores >= threshold).astype(int)

    return model.predict(X_test)

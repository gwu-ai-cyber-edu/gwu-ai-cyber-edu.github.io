import pandas as pd


LEAKAGE_COLUMNS = ["label", "attack_category"]
DEFAULT_DROP_COLUMNS = ["timestamp", "source_ip", "destination_ip"]


def add_features(df):
    """Return a copy of df with any derived features used by your final model."""
    result = df.copy()

    # TODO: Transfer the final derived features you chose in ids_colab_explorer.ipynb.
    # Add at least three derived features that you can explain in security terms.
    # Useful directions include byte or packet totals, ratios, failed-login rates,
    # scripted user-agent flags, unusual-port flags, and reputation-risk indicators.
    #
    # Keep this function consistent with the feature engineering you report in
    # evaluation_notes.md and reflection.md.

    return result


def make_features(df, feature_columns=None):
    """Create model features without using label or attack_category."""
    enriched = add_features(df)
    drop_columns = LEAKAGE_COLUMNS + DEFAULT_DROP_COLUMNS
    base = enriched.drop(columns=drop_columns, errors="ignore")
    features = pd.get_dummies(base, columns=base.select_dtypes(include="object").columns)

    if feature_columns is not None:
        features = features.reindex(columns=feature_columns, fill_value=0)

    return features


def make_target(df):
    return (df["label"] == "suspicious").astype(int)


def train_best_model(train_df):
    """Train and return your selected final model plus metadata.

    Return:
        model: trained model or pipeline
        metadata: dict containing at least {"feature_columns": [...]}.
    """
    # TODO: Import and configure the classifier you selected after comparing models
    # in ids_colab_explorer.ipynb. You may use any scikit-learn compatible
    # classifier or pipeline. The model here should match the selected classifier
    # named in evaluation_notes.md, reflection.md, and the notebook.

    X = make_features(train_df)
    y = make_target(train_df)

    model = None  # TODO: replace with your selected classifier or pipeline.
    if model is None:
        raise NotImplementedError("Create and train your selected best model before submitting.")

    model.fit(X, y)
    metadata = {
        "feature_columns": list(X.columns),
        # TODO: Use your chosen threshold. Keep 0.5 only if that is your final choice.
        "threshold": 0.5,
        "model_name": "TODO: describe your selected model",
    }
    return model, metadata


def predict_best_model(model, metadata, test_df):
    """Return 0/1 predictions for the instructor's withheld test set."""
    feature_columns = metadata["feature_columns"]
    threshold = metadata.get("threshold", 0.5)
    X_test = make_features(test_df, feature_columns=feature_columns)

    if hasattr(model, "predict_proba"):
        scores = model.predict_proba(X_test)[:, 1]
        return (scores >= threshold).astype(int)

    return model.predict(X_test)

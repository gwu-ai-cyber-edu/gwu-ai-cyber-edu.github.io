# Intrusion Detection with Machine Learning

This lab uses synthetic network-flow datasets to explore how machine learning can support intrusion detection. You will compare at least three classification techniques, evaluate them with a train/test split and five-fold cross-validation, designate the best model for private scoring, and explain what the output would mean in a security workflow.

The dataset is intentionally simplified. Treat it as a learning dataset, not as realistic operational telemetry.

Synthetic datasets can be made easy or hard by design. This lab asks you to notice whether the features are too clean, whether the classes overlap, and whether the test results are stable across evaluation methods.

Use `label` only as the binary target. Do not use `label` or `attack_category` as model input features. `attack_category` is available for post-model analysis, not for training the binary classifier.

Use the notebook as your exploration and evidence file. Use `best_model.py` as your final reproducible scoring file. After you compare models in the notebook, copy your final feature engineering, selected classifier, and threshold choice into `best_model.py`.

## Files

- `ids_colab_explorer.ipynb`: Colab notebook with lab tasks and TODO prompts.
- `data/ids_flows_dev.csv`: 30-row development set for inspection.
- `data/ids_flows_train.csv`: 5,000-row training set.
- `data/ids_flows.csv`: compatibility copy of the development set.
- `best_model.py`: clean API starter for your selected best model and feature pipeline.
- `incident_review.md`: notes for interpreting model outputs as security alerts. Replace each `Answer here:` placeholder with your own answer.
- `evaluation_notes.md`: space for metric interpretation and workflow analysis. Replace each `Answer here:` placeholder with your own answer.
- `ai_assistance_log.md`: record of meaningful AI-agent assistance.
- `reflection.md`: answers to the lab's written reflection questions, including model comparison, dataset limits, pipeline transfer, and human review. Replace each `Answer here:` placeholder with your own answer.
- `AGENTS.md`: guidance for coding assistants.

## Colab Use

1. Upload `ids_colab_explorer.ipynb` to Google Colab.
2. Upload the `data/` directory when the notebook asks for the datasets, or upload the development and training CSV files into the Colab runtime root.
3. Run the notebook cells and complete the TODO prompts.

## Bonus Competition

The instructor has a private withheld test set that is not included in this starter package. You will submit all three classifier results, but only one model should be designated as your best model in `best_model.py`.

Bonus scoring:

- Top 5 withheld-set scores: 5 bonus points
- Top 2 withheld-set scores: 10 total bonus points
- Top 1 withheld-set score: 15 total bonus points

## Submission Package

Submit these files:

- Completed `ids_colab_explorer.ipynb` as your exploration and evidence notebook
- Completed `evaluation_notes.md` with validation and cross-validation performance for all three classifiers, with all `Answer here:` placeholders replaced
- Written model comparison explaining how the classifiers differ, which one performed best, and why
- Completed `best_model.py` with your final `add_features`, `train_best_model`, and `predict_best_model` implementation
- Completed `incident_review.md` with all `Answer here:` placeholders replaced
- Completed `reflection.md` with answers to the lab's written reflection questions, including model differences, pipeline transfer, limitations, and human review, with all `Answer here:` placeholders replaced
- Completed `ai_assistance_log.md`, if you used AI assistance

Your notebook and `evaluation_notes.md` must report performance for at least three classifiers, identify the best classifier, and explain why it performed best. Your selected best classifier, derived features, threshold choice, and feature-alignment logic must be implemented in `best_model.py`.

`best_model.py` starts as an API skeleton. Complete `add_features`, `train_best_model`, and `predict_best_model` only after you have compared your classifiers in the notebook.

## Rubric

- Security task framing: 15 points
- Data understanding: 15 points
- Three-classifier comparison: 15 points
- Train/test, cross-validation, and withheld-scoring preparation: 25 points
- Human review and limitations: 15 points
- Communication and security recommendation: 15 points

## AI Assistance

AI assistance is allowed for explaining code, debugging notebook errors, interpreting metrics, or helping you revise your written explanations. It should not replace your own security interpretation. Record meaningful AI use in `ai_assistance_log.md`.

# Evaluation Notes

Use this file to summarize the evidence from `ids_colab_explorer.ipynb`. Do not paste every notebook output here. Instead, copy the key metrics, name the model settings you used, and write a short interpretation of what the results mean for intrusion detection.

For each prompt, write your response on the indented line that begins `Answer here:`. Replace that placeholder text with your own answer.

Complete this file after you have run:

- the train/validation comparison for at least three classifiers;
- the five-fold cross-validation comparison for the same classifiers;
- the confusion matrix and threshold review for your selected classifier;
- the category review for suspicious traffic.

## Model Comparison

Fill in one block for each classifier you tested. The first three classifiers should be different classifier types, not the same classifier with small parameter changes. You may copy the block to add additional models.

For `validation F1`, use the F1 score from the train/validation split. For `CV mean F1`, use the mean F1 score from five-fold cross-validation. For `CV std F1`, use the standard deviation across folds. Round metrics to three decimals.

For `main settings`, list settings that matter for the result, such as `max_depth`, `class_weight`, `n_estimators`, threshold, or whether you used scaling.

### Classifier 1: Replace With Model Name

- Main settings:
  - Answer here: replace this line with the settings you used.
- Validation F1:
  - Answer here: replace this line with the validation F1 score.
- Five-fold CV mean F1:
  - Answer here: replace this line with the cross-validation mean F1 score.
- Five-fold CV standard deviation:
  - Answer here: replace this line with the cross-validation F1 standard deviation.
- Main strength:
  - Answer here: explain what this model appears to do well.
- Main weakness:
  - Answer here: explain a practical risk, such as overfitting, missed attacks, alert fatigue, or weak explainability.

### Classifier 2: Replace With Model Name

- Main settings:
  - Answer here: replace this line with the settings you used.
- Validation F1:
  - Answer here: replace this line with the validation F1 score.
- Five-fold CV mean F1:
  - Answer here: replace this line with the cross-validation mean F1 score.
- Five-fold CV standard deviation:
  - Answer here: replace this line with the cross-validation F1 standard deviation.
- Main strength:
  - Answer here: explain what this model appears to do well.
- Main weakness:
  - Answer here: explain a practical risk, such as overfitting, missed attacks, alert fatigue, or weak explainability.

### Classifier 3: Replace With Model Name

- Main settings:
  - Answer here: replace this line with the settings you used.
- Validation F1:
  - Answer here: replace this line with the validation F1 score.
- Five-fold CV mean F1:
  - Answer here: replace this line with the cross-validation mean F1 score.
- Five-fold CV standard deviation:
  - Answer here: replace this line with the cross-validation F1 standard deviation.
- Main strength:
  - Answer here: explain what this model appears to do well.
- Main weakness:
  - Answer here: explain a practical risk, such as overfitting, missed attacks, alert fatigue, or weak explainability.

## Selected Classifier

- Best classifier:
  - Answer here: replace this line with the classifier you selected for `best_model.ipynb`.
- Why did this classifier perform best?
  - Answer here: replace this line with your explanation.
- Did you choose the highest F1 model, or did you choose a different model for security or explainability reasons?
  - Answer here: replace this line with your explanation.
- What final threshold did you use, if any?
  - Answer here: replace this line with the threshold or say that you used the default model threshold.
- What final feature pipeline did you implement in `best_model.ipynb`?
  - Answer here: replace this line with the feature engineering and encoding steps you transferred.
- What should the instructor run in `best_model.ipynb` to reproduce your selected classifier?
  - Answer here: replace this line with the relevant function or workflow.

## Comparison Explanation

Use this section to compare the models in words. A strong answer should connect the metric results to supervised learning concepts from Week 1 and to security operations.

- Which model had the best validation score?
  - Answer here: replace this line with your answer.
- Which model had the best cross-validation score?
  - Answer here: replace this line with your answer.
- Did the same model win both comparisons? If not, what might explain the difference?
  - Answer here: replace this line with your answer.
- Which model is easiest to explain to a security analyst?
  - Answer here: replace this line with your answer.
- Which model seems most likely to overfit? Why?
  - Answer here: replace this line with your answer.
- Which model would you trust least in an IDS workflow? Why?
  - Answer here: replace this line with your answer.

## Metrics For Selected Classifier

Fill in this section only for the classifier you selected for `best_model.ipynb`.

- Validation accuracy:
  - Answer here: replace this line with the selected classifier's validation accuracy.
- Validation precision:
  - Answer here: replace this line with the selected classifier's validation precision.
- Validation recall:
  - Answer here: replace this line with the selected classifier's validation recall.
- Validation F1:
  - Answer here: replace this line with the selected classifier's validation F1.
- Five-fold cross-validation F1 scores:
  - Answer here: replace this line with the five F1 scores.
- Five-fold cross-validation mean and standard deviation:
  - Answer here: replace this line with the mean and standard deviation.
- Confusion matrix observation:
  - Answer here: replace this line with what the confusion matrix means for IDS use.

When describing the confusion matrix, do not only say whether the score is high or low. Explain the IDS meaning of false positives and false negatives. For example, a false positive may create unnecessary analyst work, while a false negative may miss suspicious traffic.

## Dataset Difficulty

Use this section to explain why the dataset was or was not easy to classify. Refer to specific features or patterns you noticed in the notebook.

- What derived features did you add or keep?
  - Answer here: replace this line with your answer.
- Why are those derived features meaningful for intrusion detection?
  - Answer here: replace this line with your answer.
- Which features make the task easier to classify?
  - Answer here: replace this line with your answer.
- Which benign and suspicious records overlap?
  - Answer here: replace this line with your answer.
- Is the dataset balanced or imbalanced?
  - Answer here: replace this line with your answer.
- What kind of noise or ambiguity would make this more realistic?
  - Answer here: replace this line with your answer.

## Category Review

Use `attack_type` only for review after prediction, not as an input feature. This section should explain whether the binary model treats all attack categories equally well.

- Which attack type appears easiest to detect?
  - Answer here: replace this line with your answer.
- Which attack type appears hardest to detect?
  - Answer here: replace this line with your answer.
- Would a binary model be enough, or would a multiclass model be useful?
  - Answer here: replace this line with your answer.

## Security Interpretation

Use this section to translate model performance into an IDS workflow.

- What does a false positive cost in this lab?
  - Answer here: replace this line with your answer.
- What does a false negative cost in this lab?
  - Answer here: replace this line with your answer.
- What threshold or escalation choice would you recommend?
  - Answer here: replace this line with your answer.
- Would your recommendation change if analyst time were scarce?
  - Answer here: replace this line with your answer.
- Would your recommendation change if missing suspicious traffic were especially costly?
  - Answer here: replace this line with your answer.

## Human Review

Use this section to describe what information should accompany a model alert.

- What evidence should a human analyst inspect?
  - Answer here: replace this line with your answer.
- What should not be automated based on the model output alone?
  - Answer here: replace this line with your answer.
- What would make the alert easier to trust, challenge, or correct?
  - Answer here: replace this line with your answer.

## Limitation

- What limitation of the data, model, or workflow should students notice?
  - Answer here: replace this line with your answer.
- What would you need before making a real deployment decision?
  - Answer here: replace this line with your answer.

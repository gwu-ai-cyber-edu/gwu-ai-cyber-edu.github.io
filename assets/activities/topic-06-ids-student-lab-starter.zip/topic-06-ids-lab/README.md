# Intrusion Detection with Machine Learning

This lab uses synthetic network log records to explore how machine learning can support intrusion detection. You will compare at least three classification techniques, evaluate them with a train/validation split and five-fold cross-validation, designate the best model for the private competition test set, and explain what the output would mean in a security workflow.

The training data is synthetic. It is generated to share the same column layout as a real public cybersecurity threat-detection dataset on Kaggle, which the instructor uses as the private competition test set. The synthetic data is intentionally simplified. Treat it as a learning dataset, not as realistic operational telemetry.

Throughout the starter package, "validation" refers to the local train/validation split you create from the training data. "Test" is reserved for the private competition test set used for bonus scoring.

Use `label` only as the binary target. `label` is an integer where `0` means benign and `1` means an attack. Do not use `label` or `attack_type` as model input features. `attack_type` is available for post-model analysis, not for training the binary classifier.

Use the notebook as your exploration and evidence file. Use `best_model.py` as your final reproducible scoring file. After you compare models in the notebook, copy your final feature engineering, selected classifier, and threshold choice into `best_model.py`.

The notebook contains TODOs in both code cells and markdown cells. Complete the code TODOs, replace notebook `Answer here:` placeholders, and complete the separate Markdown files. The total submission is graded, not just whether the notebook runs.

## Files

- `ids_colab_explorer.ipynb`: Colab notebook with code TODOs and written-answer prompts.
- `data/ids_flows_dev.csv`: small development set for inspection.
- `data/ids_flows_train.csv`: 5,000-row synthetic training set.
- `data/ids_flows.csv`: compatibility copy of the development set.
- `best_model.py`: clean API starter for your selected best model and feature pipeline.
- `incident_review.md`: notes for interpreting model outputs as security alerts. Replace each `Answer here:` placeholder with your own answer.
- `evaluation_notes.md`: space for metric interpretation and workflow analysis. Replace each `Answer here:` placeholder with your own answer.
- `ai_assistance_log.md`: record of meaningful AI-agent assistance.
- `reflection.md`: answers to the lab's written reflection questions, including model comparison, dataset limits, pipeline transfer, and human review. Replace each `Answer here:` placeholder with your own answer.
- `AGENTS.md`: guidance for coding assistants.

## Dataset Schema

The training file and the private competition test file share these 13 columns:

| Column | Description |
| --- | --- |
| `timestamp` | Connection time as `YYYY-MM-DD HH:MM:SS`. |
| `src_ip` | Source IP address. |
| `dst_ip` | Destination IP address. |
| `src_port` | Source port. |
| `dst_port` | Destination port. |
| `protocol` | `TCP`, `UDP`, or `ICMP`. |
| `bytes_sent` | Bytes from source to destination. |
| `bytes_received` | Bytes from destination to source. |
| `user_agent` | Client user-agent string, where one was observed. |
| `url` | Requested URL when applicable. May be missing. |
| `is_internal_traffic` | `True` for internal-to-internal traffic, `False` otherwise. |
| `label` | `0` for benign, `1` for an attack. |
| `attack_type` | `benign` or a specific attack category (for example `port-scan`, `sql-injection`, `ddos`). |

## Colab Use

This lab runs in Google Colab and reads its data from your Google Drive.

1. **Unzip** the starter package on your computer. You will get a folder named `topic-06-ids-lab`.
2. **Upload the whole `topic-06-ids-lab` folder to your Google Drive.** The simplest place is the top level of *My Drive*, so the folder ends up at `My Drive/topic-06-ids-lab`. Upload the folder as-is so the `data/` subfolder comes along with it.
3. Open `ids_colab_explorer.ipynb` in Google Colab (upload it, or right-click it in Drive and choose *Open with → Google Colaboratory*).
4. Run the first code cell. It calls `drive.mount('/content/drive')` and prompts you to authorize Drive access. The cell then sets:

   ```python
   DATA_DIR = '/content/drive/MyDrive/topic-06-ids-lab/data'
   ```

   and loads the CSVs with `pd.read_csv(DATA_DIR + '/' + 'ids_flows_dev.csv')`.
5. **If you uploaded the folder somewhere other than the top of My Drive, edit `DATA_DIR` to match.** For example, if you placed the folder inside a `labs` folder, use `'/content/drive/MyDrive/labs/topic-06-ids-lab/data'`.
6. Run the remaining cells, complete the code TODOs, and replace notebook `Answer here:` placeholders.

## Bonus Competition

The instructor has a private competition test set that is not included in this starter package. The competition test set is the real cybersecurity threat-detection dataset from Kaggle. You will compare your three classifier results locally with a train/validation split and five-fold cross-validation, but only one model should be designated as your best model in `best_model.py`. The instructor will use `best_model.py` to score your selected pipeline against the private competition test set.

Bonus scoring:

- Top 5 competition scores: 5 bonus points
- Top 2 competition scores: 10 total bonus points
- Top 1 competition score: 15 total bonus points

## Submission Package

Submit these files:

- Completed `ids_colab_explorer.ipynb` as your exploration and evidence notebook, with code TODOs completed and written answers provided
- Completed `evaluation_notes.md` with validation and cross-validation performance for all three classifiers, with all `Answer here:` placeholders replaced
- Written model comparison explaining how the classifiers differ, which one performed best, and why
- Completed `best_model.py` with your final `add_features`, `train_best_model`, and `predict_best_model` implementation
- Completed `incident_review.md` with all `Answer here:` placeholders replaced
- Completed `reflection.md` with answers to the lab's written reflection questions, including model differences, pipeline transfer, limitations, and human review, with all `Answer here:` placeholders replaced
- Completed `ai_assistance_log.md`, if you used AI assistance

Your notebook and `evaluation_notes.md` must report performance for at least three classifier types, identify the best classifier, and explain why it performed best. Your selected best classifier, derived features, threshold choice, and feature-alignment logic must be implemented in `best_model.py`.

`best_model.py` starts as an API skeleton. Complete `add_features`, `train_best_model`, and `predict_best_model` only after you have compared your classifiers in the notebook. The feature engineering and selected model in `best_model.py` should match what you describe in the notebook, `evaluation_notes.md`, and `reflection.md`.

### How To Submit

Submit through the course **submission Google Form** (your instructor will share the link on the course page or in class).

1. Enter your name and any identifier the form requests.
2. Use the file-upload question to attach your files. At minimum, attach `best_model.py` (the file scored for the bonus competition). Attach the rest of the submission-package files too, unless your instructor collects them separately.
3. In the short-answer fields, enter your selected model name (for example, "random forest") and a one-line description of your final pipeline for the leaderboard.
4. Submit. Uploading requires you to be signed in to the same Google account you used for Colab.

Do not rename `best_model.py`. The form records your name automatically, and the scoring script expects the standard filename and function names.

## AI Agent Use

You may use AI agents or assistants for debugging, explaining code, or brainstorming model and feature choices. The starter package includes `AGENTS.md`, which describes the intended boundaries for agent help. Work within those constraints when using an agent for this assignment. The point is to learn how the modeling choices, metrics, and security interpretation fit together, not to outsource the reasoning.

An agent may help you understand errors, compare possible approaches, or think through alternatives. You remain responsible for the final feature choices, classifier choices, written explanations, security interpretation, and submitted code. Record meaningful AI help in `ai_assistance_log.md`.

## Rubric

- Security task framing: 15 points
- Data understanding: 15 points
- Three-classifier comparison: 15 points
- Train/validation, cross-validation, and competition-scoring preparation: 25 points
- Human review and limitations: 15 points
- Communication and security recommendation: 15 points

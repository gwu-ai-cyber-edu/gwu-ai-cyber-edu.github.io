# Incident Review Notes

Use this file to connect model outputs to security review decisions.

For each prompt, write your response on the indented line that begins `Answer here:`. Replace that placeholder text with your own answer.

## Alert Interpretation

- What does the model label as an attack?
  - Answer here: replace this line with your answer.
- Which features seem most connected to the attack label?
  - Answer here: replace this line with your answer.
- What additional context would you want before treating an alert as actionable?
  - Answer here: replace this line with your answer.

## False Positive Review

- What might happen if benign traffic is flagged as an attack?
  - Answer here: replace this line with your answer.
- How could repeated false positives affect analyst workload or trust?
  - Answer here: replace this line with your answer.

## False Negative Review

- What might happen if an attack is labeled benign?
  - Answer here: replace this line with your answer.
- What additional detection or review process could reduce this risk?
  - Answer here: replace this line with your answer.

## Escalation Decision

- Would you automatically block traffic based on this model output?
  - Answer here: replace this line with your answer.
- Would you send alerts to a human analyst?
  - Answer here: replace this line with your answer.
- What evidence should appear in the alert record?
  - Answer here: replace this line with your answer.

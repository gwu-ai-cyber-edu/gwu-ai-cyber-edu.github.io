# Topic 06 IDS Colab Starter

This starter package supports the Topic 06 IDS exemplar lab. It is designed for Google Colab and uses a small synthetic network-flow dataset.

## Files

- `ids_colab_starter.ipynb`: Colab notebook with TODO prompts.
- `data/ids_flows.csv`: small synthetic flow dataset.
- `lab_design_notes.md`: notes on how this lab is structured for teaching.
- `evaluation_notes.md`: space for metric interpretation and workflow analysis.
- `ai_assistance_log.md`: record of meaningful AI-agent assistance.
- `reflection.md`: short reflection on classroom fit and limitations.
- `AGENTS.md`: guidance for coding assistants.

## Colab Use

1. Upload `ids_colab_starter.ipynb` to Google Colab.
2. Upload `data/ids_flows.csv` when the notebook asks for the dataset.
3. Run the notebook cells and complete the TODO prompts.

## Student-Facing Rubric

- Security task framing: 15 points
- Data understanding: 15 points
- Model implementation: 20 points
- Evaluation interpretation: 20 points
- Human review and limitations: 15 points
- Communication and classroom fit: 15 points

## AI Assistance

AI assistance is allowed for explaining code, suggesting notebook structure, drafting comparison language, or brainstorming rubric criteria. It should not replace the participant's own design judgment. Record meaningful AI use in `ai_assistance_log.md`.


# Evaluation Notes

## Metrics

- Accuracy:
- Precision:
- Recall:
- Confusion matrix observation:

## Security Interpretation

- What does a false positive cost in this lab?
- What does a false negative cost in this lab?
- What threshold or escalation choice would you discuss with students?

## Human Review

- What evidence should a human analyst inspect?
- What should not be automated based on the model output alone?

## Limitation

- What limitation of the data, model, or workflow should students notice?


# AGENTS.md - Topic 06 IDS Colab Starter

Support learning-oriented help only.

When assisting with this starter package:

- Help explain code, metrics, and security concepts.
- Help debug notebook execution and data-loading issues.
- Ask the participant to make the final design choices.
- Do not complete `evaluation_notes.md`, `lab_design_notes.md`, `reflection.md`, or `ai_assistance_log.md` as a finished submission.
- Do not claim the synthetic dataset is realistic operational network telemetry.

The goal is to help participants prototype a teachable lab while preserving their own judgment about learning objectives, data feasibility, tradeoffs, and classroom fit.


# Lab Design Notes

## Course Context

- Course:
- Level:
- Time available:
- Prerequisites:

## Learning Objective

Students will be able to:

1.

## Security Task

- What security decision or workflow does the lab model?
- What does the model help with?
- What does the human still decide?

## Dataset Plan

- Data source:
- Synthetic, curated, public, or instructor-provided:
- Label readiness:
- Classroom-size feasibility:
- Fallback if realistic data is unavailable:

## Student Task

- What do students actually do?
- What do they submit?

## Classroom Fit

- Where would this fit in a course?
- What misconception should the instructor watch for?


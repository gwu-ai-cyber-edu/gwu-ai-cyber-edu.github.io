# Reflection

## Classroom Use

- How could this lab fit into your course?

## Tradeoff

- What tradeoff should students notice?

## Data Feasibility

- What data concern would you need to solve before using this lab?

## Improvement

- What would you change before assigning this to students?

